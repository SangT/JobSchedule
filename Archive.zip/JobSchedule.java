import java.util.*;

public class JobSchedule
{
    private final List<Job> jobs = new ArrayList<>();

    public Job addJob(final int time)
    {
//        assert time >= 0;
        final Job j = new Job(time);
        jobs.add(j);
        return j;
    }

    public Job getJob(final int i)
    {
//        assert i >= 0;
//        assert i < jobs.size();
        return jobs.get(i);
    }

    /**
     * Calculates the minimum amount of time for the graph to be completed.
     * @return minimum completion time
     */
    public int minCompletionTime()
    {
//        if (jobs.isEmpty())
//            return -1;
        final List<Job> sorted = topologicalSort(jobs);
        if (sorted.size() < jobs.size()) 
            return -1;
        
        final Job lastJob = sorted.get(sorted.size() - 1);
        int minTime = lastJob.getStartTime(sorted) + lastJob.time;
        
        for (int i = sorted.size() - 2; i >= 0; i--)
        {
            final Job u = sorted.get(i);
            minTime = Math.max(minTime, u.inDegree + u.time);
        }
        
        return minTime;
    }

    /**
     * Produces a topologically sorted list of Jobs from a provided list.
     * Sorted via Kahn's Algorithm.
     * @param jobs - Jobs to be topologically sorted.
     * @return new topologically sorted list of Jobs.
     */
    private static List<Job> topologicalSort(final List<Job> jobs)
    {
//        assert jobs != null;
        /* Prepare all job's inDegrees to be incremented. */
        for (final Job u : jobs)
           u.inDegree = 0;
        /* Count how many jobs each job requires. */
        for (final Job u : jobs)
            for (final Job v : u.outbound)
                v.inDegree++;
        
        final List<Job> sorted = new ArrayList<>(jobs.size());
        /* Jobs which have no requirements are the entry points into the graph. */
        for (final Job u : jobs) 
            if (u.inDegree == 0) 
                sorted.add(u);
        
        for (int i = 0; i < sorted.size(); i++)
        {
            final Job u = sorted.get(i);
            for (final Job v : u.outbound)
                /* Remove edges until a node's requirements become exhausted. */
                if (--v.inDegree == 0) 
                    sorted.add(v);
        }
        
        return sorted;
    }

    public final class Job
    {
        private final int time;
        private final List<Job> outbound;

        private int inDegree;

        private Job(final int time)
        {
            this.time = time;
            outbound = new ArrayList<>();
            inDegree = 0;
        }

        public void requires(final Job j)
        {
            j.outbound.add(this);
        }
        
        /* Helper method. Called when graph is already topologically sorted. */
        private int getStartTime(final List<Job> topoSorted)
        {
//            assert topoSorted != null;
//            assert topoSorted.equals(topologicalSort(topoSorted));
//            assert topoSorted.stream().allMatch(j -> j.inDegree == 0);
            /* At this point, all jobs in the sorted list will have inDegree = 0 */
            for (final Job u : topoSorted)
            {
                /* We are using inDegree as the start time, despite the name. */
                final int startTime = u.inDegree;
                /* End iterating when we find this node. */
                if (u == this)
                    return startTime;
                final int completionTime = startTime + u.time;
                /* "Relax" all outgoing edges. */
                for (final Job v : u.outbound)
                    v.inDegree = Math.max(v.inDegree, completionTime);
            }
            
            /* This node was not found while iterating. */
            return -1;
        }

        /**
         * Gets the time it will take for this Job to begin.
         * @return time to begin or -1 if infinite loop.
         */
        public int getStartTime()
        {
            final List<Job> sorted = topologicalSort(jobs);
            return getStartTime(sorted);
        }
    }
}